CPT is 7kw charger FW directory
