- this dir is ocpp-cpt,client.dat file exist
- restored from this dir/files, when 3rd boot try failed

